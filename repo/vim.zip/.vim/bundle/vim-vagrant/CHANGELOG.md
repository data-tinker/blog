# vim-vagrant CHANGELOG

## Version 1.1.2 (December 10, 2014)

* update with commands in Vagrant 1.7

## Version 1.1.1 (June 7, 2013)

* move ftplugin to ftdetect

## Version 1.1.0 (May 21, 2013)

* don't load plugin if vagrant isn't installed
* add MIT license

## Version 1.0.0 (April 25, 2013)

* Initial release
